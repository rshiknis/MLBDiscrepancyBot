import discrepancy_bot
if __name__ =='__main__':
    discrepancy_bot.runBot()